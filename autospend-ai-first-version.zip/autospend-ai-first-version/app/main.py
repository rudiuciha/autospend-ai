from fastapi import FastAPI
from dotenv import load_dotenv

from app.ai_parser import parse_expense_text
from app.expense_store import init_db, save_expense, list_expenses, get_summary
from app.models import ExpenseTextRequest


load_dotenv()

app = FastAPI(
    title="AutoSpend AI",
    description="AI-powered personal expense logger MVP",
    version="0.1.0",
)


@app.on_event("startup")
def startup_event() -> None:
    init_db()


@app.get("/")
def root() -> dict:
    return {
        "name": "AutoSpend AI",
        "status": "running",
        "message": "Send transaction text to POST /expenses/parse",
    }


@app.post("/expenses/parse")
def parse_and_save_expense(payload: ExpenseTextRequest) -> dict:
    expense = parse_expense_text(payload.text)
    saved = save_expense(expense)
    return saved


@app.get("/expenses")
def get_expenses() -> list[dict]:
    return list_expenses()


@app.get("/expenses/summary")
def summary() -> dict:
    return get_summary()
