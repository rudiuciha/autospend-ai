import os
import sqlite3
from typing import Any
from app.models import Expense


DATABASE_PATH = os.getenv("DATABASE_PATH", "autospend.db")


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount INTEGER NOT NULL,
                currency TEXT NOT NULL,
                merchant TEXT NOT NULL,
                category TEXT NOT NULL,
                payment_method TEXT,
                transaction_date TEXT,
                raw_text TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )


def save_expense(expense: Expense) -> dict[str, Any]:
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO expenses (
                amount, currency, merchant, category,
                payment_method, transaction_date, raw_text
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                expense.amount,
                expense.currency,
                expense.merchant,
                expense.category,
                expense.payment_method,
                expense.transaction_date,
                expense.raw_text,
            ),
        )
        conn.commit()
        return {"id": cursor.lastrowid, **expense.model_dump()}


def list_expenses() -> list[dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT id, amount, currency, merchant, category,
                   payment_method, transaction_date, raw_text, created_at
            FROM expenses
            ORDER BY id DESC
            """
        ).fetchall()
        return [dict(row) for row in rows]


def get_summary() -> dict[str, Any]:
    expenses = list_expenses()
    total_amount = sum(item["amount"] for item in expenses)
    by_category: dict[str, int] = {}

    for item in expenses:
        category = item["category"]
        by_category[category] = by_category.get(category, 0) + item["amount"]

    return {
        "total_amount": total_amount,
        "total_transactions": len(expenses),
        "by_category": by_category,
    }
