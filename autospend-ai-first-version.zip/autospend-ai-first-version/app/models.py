from pydantic import BaseModel, Field
from typing import Optional


class ExpenseTextRequest(BaseModel):
    text: str = Field(..., min_length=3, description="Raw transaction text from notification or email")


class Expense(BaseModel):
    amount: int
    currency: str = "IDR"
    merchant: str
    category: str
    payment_method: Optional[str] = None
    transaction_date: Optional[str] = None
    raw_text: str


class ExpenseSummary(BaseModel):
    total_amount: int
    total_transactions: int
    by_category: dict[str, int]
