import re
from datetime import datetime
from app.models import Expense


CATEGORY_KEYWORDS = {
    "Food": ["kopi", "resto", "restaurant", "makan", "ayam", "bakso", "mie", "nasi", "cafe", "warung"],
    "Transport": ["gojek", "grab", "maxim", "taxi", "ojek", "parkir", "tol", "pertamina", "shell", "bensin"],
    "Shopping": ["shopee", "tokopedia", "lazada", "tiktok shop", "alfamart", "indomaret", "mall"],
    "Bills": ["pln", "listrik", "wifi", "internet", "pulsa", "tagihan", "bpjs", "pdam"],
    "Health": ["apotek", "obat", "klinik", "dokter", "rumah sakit"],
    "Entertainment": ["bioskop", "cinema", "netflix", "spotify", "game", "steam"],
    "Transfer": ["transfer", "kirim uang", "top up", "topup"],
}

PAYMENT_METHODS = ["DANA", "OVO", "GoPay", "ShopeePay", "QRIS", "BCA", "BRI", "BNI", "Mandiri", "SeaBank"]


def parse_amount(text: str) -> int:
    patterns = [
        r"Rp\s?([0-9\.\,]+)",
        r"IDR\s?([0-9\.\,]+)",
        r"sebesar\s?([0-9\.\,]+)",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            raw = match.group(1)
            digits = re.sub(r"[^0-9]", "", raw)
            return int(digits) if digits else 0

    numbers = re.findall(r"\b[0-9]{4,}\b", re.sub(r"[.,]", "", text))
    return int(numbers[0]) if numbers else 0


def parse_payment_method(text: str) -> str | None:
    lower = text.lower()
    for method in PAYMENT_METHODS:
        if method.lower() in lower:
            return method
    return None


def parse_category(text: str) -> str:
    lower = text.lower()
    for category, keywords in CATEGORY_KEYWORDS.items():
        if any(keyword in lower for keyword in keywords):
            return category
    return "Other"


def parse_merchant(text: str) -> str:
    patterns = [
        r"di\s+([A-Za-z0-9\s&.'-]+?)(?:\s+tanggal|\s+pakai|\s+dengan|$)",
        r"ke\s+([A-Za-z0-9\s&.'-]+?)(?:\s+tanggal|\s+pakai|\s+dengan|$)",
        r"merchant\s+([A-Za-z0-9\s&.'-]+?)(?:\s+tanggal|\s+pakai|\s+dengan|$)",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            merchant = match.group(1).strip(" .,-")
            if merchant:
                return merchant

    return "Unknown Merchant"


def parse_date(text: str) -> str:
    return datetime.now().date().isoformat()


def parse_expense_text(text: str) -> Expense:
    return Expense(
        amount=parse_amount(text),
        currency="IDR",
        merchant=parse_merchant(text),
        category=parse_category(text),
        payment_method=parse_payment_method(text),
        transaction_date=parse_date(text),
        raw_text=text,
    )
