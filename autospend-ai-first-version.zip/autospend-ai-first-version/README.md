# AutoSpend AI

AutoSpend AI adalah MVP AI agent pengelola keuangan pribadi yang membantu mencatat pengeluaran otomatis dari teks transaksi, notifikasi pembayaran, atau email bukti transaksi.

Project ini cocok untuk ide Xiaomi MiMo karena menyelesaikan masalah sehari-hari: pengguna sering lupa mencatat pengeluaran kecil. AutoSpend AI mengubah teks transaksi menjadi data terstruktur seperti nominal, merchant, kategori, tanggal, dan metode pembayaran.

## Fitur MVP

- Parse teks transaksi menjadi JSON pengeluaran.
- Kategori otomatis: Food, Transport, Shopping, Bills, Health, Entertainment, Transfer, Other.
- Simpan transaksi ke SQLite lokal.
- API sederhana dengan FastAPI.
- Endpoint statistik pengeluaran.
- Aman untuk demo karena tidak perlu akses bank langsung.

## Alur Kerja

1. User menerima notifikasi pembayaran atau email struk.
2. Teks transaksi dikirim ke API AutoSpend AI.
3. AI/parser mengambil nominal, merchant, kategori, dan tanggal.
4. Data disimpan ke database lokal.
5. User bisa melihat riwayat dan statistik pengeluaran.

## Instalasi

```bash
git clone https://github.com/rudiuciha/autospend-ai.git
cd autospend-ai
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Contoh Request

```bash
curl -X POST http://localhost:8000/expenses/parse \
  -H "Content-Type: application/json" \
  -d '{"text":"Pembayaran QRIS berhasil Rp25.000 di Kopi Kenangan tanggal 22 Mei 2026 pakai DANA"}'
```

## Endpoint

- `GET /` status API.
- `POST /expenses/parse` parse dan simpan transaksi dari teks.
- `GET /expenses` lihat semua transaksi.
- `GET /expenses/summary` lihat total dan ringkasan kategori.

## Catatan Privasi

AutoSpend AI MVP ini hanya memproses teks yang dikirim user. Tidak menyimpan password, OTP, token bank, atau kredensial email.

## Roadmap

- Integrasi Gmail API untuk membaca email receipt dengan izin user.
- Integrasi Android Notification Listener untuk menangkap notifikasi pembayaran.
- Dashboard mobile/web.
- Budget alert dan rekomendasi hemat otomatis.
- Export CSV.

## License

MIT
