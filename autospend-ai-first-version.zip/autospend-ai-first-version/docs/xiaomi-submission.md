# Xiaomi MiMo Submission: AutoSpend AI

## Nama Project
AutoSpend AI

## Masalah
Banyak orang ingin mengatur keuangan, tetapi gagal karena malas atau lupa mencatat pengeluaran kecil. Transaksi harian biasanya muncul sebagai notifikasi pembayaran, QRIS, e-wallet, mobile banking, atau email receipt. Data ini sudah ada, tetapi belum otomatis menjadi catatan keuangan yang rapi.

## Solusi
AutoSpend AI adalah AI agent yang mengubah teks transaksi menjadi catatan pengeluaran otomatis. User cukup memberi teks dari notifikasi atau email transaksi, lalu sistem mengekstrak nominal, merchant, kategori, tanggal, dan metode pembayaran.

## Kenapa Cocok untuk Masalah Sehari-hari
- Hampir semua orang punya transaksi digital.
- Pengeluaran kecil sering tidak dicatat.
- Aplikasi budgeting manual terasa merepotkan.
- Solusi ini bisa dibuat sederhana, tetapi sangat berguna.

## Fitur Utama MVP
1. Transaction text parser.
2. Kategori otomatis.
3. Penyimpanan SQLite lokal.
4. API untuk integrasi Android, Gmail, atau dashboard.
5. Summary pengeluaran per kategori.

## Contoh
Input:

> Pembayaran QRIS berhasil Rp25.000 di Kopi Kenangan tanggal 22 Mei 2026 pakai DANA

Output:

```json
{
  "amount": 25000,
  "currency": "IDR",
  "merchant": "Kopi Kenangan",
  "category": "Food",
  "payment_method": "DANA",
  "transaction_date": "2026-05-22"
}
```

## Potensi Integrasi Xiaomi
- Notification listener di HP Xiaomi.
- Analisis transaksi lokal untuk menjaga privasi.
- Reminder hemat berdasarkan kebiasaan pengguna.
- Ringkasan pengeluaran harian di MiMo assistant.
- Budget alert saat user terlalu sering belanja kategori tertentu.

## Nilai AI
AI digunakan untuk memahami teks transaksi yang formatnya berbeda-beda, lalu mengubahnya menjadi data rapi. Versi lanjut bisa memakai LLM untuk ekstraksi lebih akurat, rekomendasi hemat, dan deteksi pola pengeluaran.

## Roadmap
- Gmail receipt reader.
- Android notification listener.
- Dashboard mobile.
- Budget recommendation.
- Export CSV dan laporan bulanan.
- Privacy-first local processing.
