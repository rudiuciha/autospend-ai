from sqlalchemy import Column, DateTime, Float, Integer, String, Text, func
from .db import Base


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    raw_text = Column(Text, nullable=False)
    tx_type = Column(String(32), default="expense")
    amount = Column(Float, nullable=False, default=0)
    currency = Column(String(8), default="IDR")
    merchant = Column(String(128), default="Unknown")
    category = Column(String(64), default="uncategorized")
    payment_method = Column(String(64), default="unknown")
    tx_date = Column(String(32), default="unknown")
    confidence = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
