import json
import os
import re
from typing import Any, Dict

import httpx
from dotenv import load_dotenv

load_dotenv()

CATEGORIES = [
    "food", "transport", "shopping", "bills", "subscription",
    "entertainment", "health", "income", "refund", "uncategorized"
]


def _number_from_text(text: str) -> float:
    patterns = [r"Rp\s?([0-9\.\,]+)", r"IDR\s?([0-9\.\,]+)", r"([0-9\.\,]+)\s?rupiah"]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            value = match.group(1).replace(".", "").replace(",", ".")
            try:
                return float(value)
            except ValueError:
                pass
    return 0.0


def fallback_parse(text: str) -> Dict[str, Any]:
    lower = text.lower()
    amount = _number_from_text(text)

    category = "uncategorized"
    if any(w in lower for w in ["gofood", "grabfood", "resto", "warung", "kopi", "makan"]):
        category = "food"
    elif any(w in lower for w in ["grab", "gojek", "maxim", "taxi", "parkir", "tol"]):
        category = "transport"
    elif any(w in lower for w in ["pln", "pulsa", "tagihan", "internet", "pdam"]):
        category = "bills"
    elif any(w in lower for w in ["netflix", "spotify", "subscription", "langganan"]):
        category = "subscription"
    elif any(w in lower for w in ["refund", "pengembalian"]):
        category = "refund"
    elif any(w in lower for w in ["transfer masuk", "menerima", "gaji"]):
        category = "income"
    elif any(w in lower for w in ["indomaret", "alfamart", "shopee", "tokopedia", "lazada"]):
        category = "shopping"

    merchant = "Unknown"
    merchant_match = re.search(r"(?:di|ke|from|merchant)\s+([A-Za-z0-9 ._-]{3,40})", text, flags=re.IGNORECASE)
    if merchant_match:
        merchant = merchant_match.group(1).strip(" .-")

    payment_method = "unknown"
    for method in ["QRIS", "DANA", "OVO", "GoPay", "ShopeePay", "BCA", "BRI", "BNI", "Mandiri"]:
        if method.lower() in lower:
            payment_method = method
            break

    return {
        "type": "income" if category == "income" else "expense",
        "amount": amount,
        "currency": "IDR",
        "merchant": merchant,
        "category": category,
        "payment_method": payment_method,
        "date": "unknown",
        "confidence": 0.55 if amount else 0.25,
    }


async def parse_with_mimo(text: str) -> Dict[str, Any]:
    api_key = os.getenv("MIMO_API_KEY", "")
    base_url = os.getenv("MIMO_BASE_URL", "").rstrip("/")
    model = os.getenv("MIMO_MODEL", "mimo-v2.5")

    if not api_key or "example" in base_url or not base_url:
        return fallback_parse(text)

    prompt = f"""
Extract one financial transaction from this text. Return only valid JSON.

Text: {text}

JSON schema:
{{
  "type": "expense|income|refund",
  "amount": number,
  "currency": "IDR",
  "merchant": string,
  "category": one of {CATEGORIES},
  "payment_method": string,
  "date": string,
  "confidence": number between 0 and 1
}}
""".strip()

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                f"{base_url}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={
                    "model": model,
                    "messages": [
                        {"role": "system", "content": "You extract Indonesian transaction notifications into strict JSON."},
                        {"role": "user", "content": prompt},
                    ],
                    "temperature": 0.1,
                },
            )
            response.raise_for_status()
            content = response.json()["choices"][0]["message"]["content"]
            return json.loads(content)
    except Exception:
        return fallback_parse(text)
