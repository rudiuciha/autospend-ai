from pydantic import BaseModel, Field


class ParseRequest(BaseModel):
    text: str = Field(..., examples=["Pembayaran QRIS Rp35.000 di Indomaret berhasil"])


class TransactionOut(BaseModel):
    id: int
    raw_text: str
    tx_type: str
    amount: float
    currency: str
    merchant: str
    category: str
    payment_method: str
    tx_date: str
    confidence: float

    class Config:
        from_attributes = True
