from collections import defaultdict

from fastapi import Depends, FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from .ai import parse_with_mimo
from .db import get_db, init_db
from .models import Transaction
from .schemas import ParseRequest, TransactionOut

app = FastAPI(
    title="AutoSpend AI",
    description="AI agent that automatically logs daily expenses from notifications, emails, and receipts.",
    version="0.1.0",
)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/api/parse", response_model=TransactionOut)
async def parse_transaction(payload: ParseRequest, db: Session = Depends(get_db)):
    parsed = await parse_with_mimo(payload.text)
    tx = Transaction(
        raw_text=payload.text,
        tx_type=parsed.get("type", "expense"),
        amount=float(parsed.get("amount") or 0),
        currency=parsed.get("currency", "IDR"),
        merchant=parsed.get("merchant", "Unknown"),
        category=parsed.get("category", "uncategorized"),
        payment_method=parsed.get("payment_method", "unknown"),
        tx_date=parsed.get("date", "unknown"),
        confidence=float(parsed.get("confidence") or 0),
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)
    return tx


@app.get("/api/transactions", response_model=list[TransactionOut])
def list_transactions(db: Session = Depends(get_db)):
    return db.query(Transaction).order_by(Transaction.id.desc()).limit(100).all()


@app.get("/api/summary")
def summary(db: Session = Depends(get_db)):
    rows = db.query(Transaction).all()
    total_expense = sum(tx.amount for tx in rows if tx.tx_type in ["expense", "refund"] and tx.category != "income")
    total_income = sum(tx.amount for tx in rows if tx.tx_type == "income" or tx.category == "income")
    by_category = defaultdict(float)
    for tx in rows:
        if tx.category != "income":
            by_category[tx.category] += tx.amount
    biggest = max(by_category.items(), key=lambda x: x[1], default=("none", 0))
    return {
        "transaction_count": len(rows),
        "total_expense": total_expense,
        "total_income": total_income,
        "biggest_category": {"category": biggest[0], "amount": biggest[1]},
        "by_category": dict(sorted(by_category.items(), key=lambda x: x[1], reverse=True)),
    }


@app.post("/api/demo-seed")
async def seed_demo(db: Session = Depends(get_db)):
    samples = [
        "Pembayaran QRIS Rp35.000 di Indomaret berhasil menggunakan BCA",
        "GoPay: Kamu membayar Rp22.000 ke Kopi Kenangan",
        "Transfer masuk Rp500.000 dari BUDI ke rekening BCA kamu",
        "Tagihan Netflix Rp54.000 berhasil dibayar dengan DANA",
        "Grab: Perjalanan selesai, total pembayaran Rp18.500",
    ]
    created = []
    for text in samples:
        parsed = await parse_with_mimo(text)
        tx = Transaction(
            raw_text=text,
            tx_type=parsed.get("type", "expense"),
            amount=float(parsed.get("amount") or 0),
            currency=parsed.get("currency", "IDR"),
            merchant=parsed.get("merchant", "Unknown"),
            category=parsed.get("category", "uncategorized"),
            payment_method=parsed.get("payment_method", "unknown"),
            tx_date=parsed.get("date", "unknown"),
            confidence=float(parsed.get("confidence") or 0),
        )
        db.add(tx)
        created.append(tx)
    db.commit()
    return {"created": len(created)}
