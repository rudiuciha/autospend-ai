# AutoSpend AI

AutoSpend AI is a personal finance AI agent that automatically logs daily expenses from Android notifications, email receipts, and receipt photos.

This project is designed as a Xiaomi MiMo Orbit submission prototype.

## Problem

Most users want to track spending, but manual expense logging is boring and easy to forget. Transactions are scattered across e-wallets, banks, marketplace emails, subscriptions, and physical receipts.

## Solution

AutoSpend AI converts passive transaction traces into a structured personal finance journal. It extracts amount, merchant, category, payment method, and date, then displays summaries in a dashboard.

## MVP Features

- Parse Indonesian transaction notification text
- Extract amount, merchant, category, payment method, and transaction type
- Store transactions in SQLite
- Dashboard for total expense, income, biggest category, and recent transactions
- MiMo/OpenAI-compatible parser support
- Fallback local parser when no API key is configured

## Architecture

```text
Android Notification / Email Receipt / Receipt Photo
        ↓
FastAPI Backend
        ↓
MiMo AI Parser
        ↓
SQLite Database
        ↓
Web Dashboard + Chat Interface
```

## Tech Stack

- FastAPI
- SQLite / SQLAlchemy
- MiMo API or OpenAI-compatible chat completions endpoint
- HTML/CSS/JavaScript dashboard

## Setup

```bash
git clone https://github.com/YOUR_USERNAME/autospend-ai.git
cd autospend-ai
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## MiMo Configuration

Edit `.env`:

```env
MIMO_API_KEY=your_mimo_api_key_here
MIMO_BASE_URL=https://your-mimo-openai-compatible-base-url/v1
MIMO_MODEL=mimo-v2.5
```

If no MiMo key is configured, the app still works using the local fallback parser.

## Example Input

```text
Pembayaran QRIS Rp35.000 di Indomaret berhasil menggunakan BCA
```

## Example Output

```json
{
  "type": "expense",
  "amount": 35000,
  "currency": "IDR",
  "merchant": "Indomaret",
  "category": "shopping",
  "payment_method": "QRIS",
  "date": "unknown",
  "confidence": 0.55
}
```

## Xiaomi MiMo Submission Pitch

AutoSpend AI is an AI-powered personal finance agent that automatically logs expenses from Android notifications, Gmail receipts, and receipt photos. It uses Xiaomi MiMo to extract structured transaction data, categorize spending, detect subscriptions, identify unusual transactions, and generate daily or monthly financial summaries.

The project solves a daily problem: people want to manage money but fail to manually record expenses. MiMo is useful because this requires structured extraction, long-context understanding, and agentic reasoning across many small daily transactions.

## Roadmap

- Android Notification Listener app
- Gmail API receipt scanner
- Receipt image OCR
- Natural-language finance chat
- Subscription detection
- Duplicate and suspicious transaction detection
