const rupiah = (n) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n || 0);

async function refresh() {
  const [summaryRes, txRes] = await Promise.all([fetch('/api/summary'), fetch('/api/transactions')]);
  const summary = await summaryRes.json();
  const transactions = await txRes.json();

  document.getElementById('totalExpense').textContent = rupiah(summary.total_expense);
  document.getElementById('totalIncome').textContent = rupiah(summary.total_income);
  document.getElementById('txCount').textContent = summary.transaction_count;
  document.getElementById('biggestCategory').textContent = `${summary.biggest_category.category} ${rupiah(summary.biggest_category.amount)}`;

  document.getElementById('transactions').innerHTML = transactions.map(tx => `
    <div class="tx">
      <div>
        <strong>${tx.merchant}</strong>
        <div class="meta">${tx.category} · ${tx.payment_method} · confidence ${Math.round(tx.confidence * 100)}%</div>
        <div class="meta">${tx.raw_text}</div>
      </div>
      <div class="amount">${rupiah(tx.amount)}</div>
    </div>
  `).join('') || '<p>No transactions yet.</p>';
}

async function parseTransaction() {
  const text = document.getElementById('txText').value.trim();
  if (!text) return alert('Masukkan teks transaksi dulu.');
  await fetch('/api/parse', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text })
  });
  document.getElementById('txText').value = '';
  await refresh();
}

async function seedDemo() {
  await fetch('/api/demo-seed', { method: 'POST' });
  await refresh();
}

refresh();
